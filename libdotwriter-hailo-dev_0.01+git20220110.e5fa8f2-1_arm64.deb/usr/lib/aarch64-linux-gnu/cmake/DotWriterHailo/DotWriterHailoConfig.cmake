# Fourni par libdotwriter-hailo-dev 0.01+git20220110.e5fa8f2-1
# Usage : find_package(DotWriterHailo REQUIRED)
#         target_link_libraries(mon_projet PRIVATE DotWriterHailo::DotWriter)
if(NOT TARGET DotWriterHailo::DotWriter)
  add_library(DotWriterHailo::DotWriter STATIC IMPORTED)
  set_target_properties(DotWriterHailo::DotWriter PROPERTIES
    IMPORTED_LOCATION             "/usr/lib/aarch64-linux-gnu/dotwriter-hailo/libdotwriter.a"
    INTERFACE_INCLUDE_DIRECTORIES "/usr/include/dotwriter-hailo"
    INTERFACE_COMPILE_FEATURES    "cxx_std_14")
endif()
set(DotWriterHailo_FOUND TRUE)
